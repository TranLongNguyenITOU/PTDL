﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuanLySinhVien
{
    public partial class GUI_SinhVien : Form
    {
        private QLSVEntities db;
        public GUI_SinhVien()
        {
            InitializeComponent();
            db = new QLSVEntities();
        }


        void LoadData()
        {
            dgView.DataSource = db.SinhViens.ToList();
        }

        void AddSV()
        {
            if (txtEmail.Text != "" && txtName.Text != "" && txtPhone.Text != "")
            {
                SinhVien newSV = new SinhVien
                {
                    SV_Name = txtName.Text,
                    SV_Phone = txtPhone.Text,
                    SV_Email = txtEmail.Text
                };

                db.SinhViens.Add(newSV);
                db.SaveChanges();

                LoadData();
            }
            else
            {
                MessageBox.Show("Xin hãy nhập đầy đủ");
            }
        }

        void EditSV()
        {

            if (dgView.SelectedRows.Count > 0)
            {
                if (txtEmail.Text != "" && txtName.Text != "" && txtPhone.Text != "")
                {
                    DataGridViewRow row = dgView.SelectedRows[0];
                    int selectedId = Convert.ToInt16(row.Cells[0].Value.ToString());

                    SinhVien sv = db.SinhViens.Find(selectedId);

                    sv.SV_Name = txtName.Text;
                    sv.SV_Phone = txtPhone.Text;
                    sv.SV_Email = txtEmail.Text;
                    db.SaveChanges();

                    LoadData();
                }
                else
                {
                    MessageBox.Show("Xin hãy nhập đầy đủ");
                }
            }
            else
            {
                MessageBox.Show("Hãy chọn thành viên muốn sửa");
            }
        }

        void DeleteSV()
        {
            if (dgView.SelectedRows.Count > 0)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa thành viên này không?", "Xác nhận xóa", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {

                    DataGridViewRow row = dgView.SelectedRows[0];
                    int selectedId = Convert.ToInt16(row.Cells[0].Value.ToString());

                    SinhVien sv = db.SinhViens.Find(selectedId);

                    db.SinhViens.Remove(sv);
                    db.SaveChanges();

                    LoadData();
                }
            }
            else
            {
                MessageBox.Show("Hãy chọn thành viên muốn xóa");
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            AddSV();

        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            EditSV();
        }


        private void btnLoad_Click(object sender, EventArgs e)
        {
            LoadData();
        }

        private void dgView_Click(object sender, EventArgs e)
        {
            DataGridViewRow row = dgView.SelectedRows[0];
            txtName.Text = row.Cells[1].Value.ToString();
            txtPhone.Text = row.Cells[2].Value.ToString();
            txtEmail.Text = row.Cells[3].Value.ToString();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DeleteSV();
        }
    }
}
